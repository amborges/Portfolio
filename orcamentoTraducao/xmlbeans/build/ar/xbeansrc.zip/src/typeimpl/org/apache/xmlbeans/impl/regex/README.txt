This is an isolated directory that was taken from the
Apache Xerces-J 2.0 project.

It contains the following modifications:

(1) a change in namespace.
(2) the addition of a SchemaRegularExpression class for fast
    detection of NCNAME, etc.

No xbean code outside this directory or other directories with
similar README notices was taken from Apache.
